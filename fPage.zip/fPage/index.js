const http = require('http');
const hostname = 'localhost';
const fs = require('fs'); // allows you read/write support from your local file system
const path = require('path');//allows to specify the path from local file system
const port = 3000;

const server = http.createServer((req,res)=>{
   console.log('Request for ' + req.url + 'by method '+ req.method);
  if(req.method == 'GET'){
      var fileUrl;
      if(req.url == '/') fileUrl = '/f.html';//if request does not specift any file, it defaults to index.html
      else fileUrl = req.url;// otherwise it specifies selected file

      var filePath = path.resolve('./public' + fileUrl);// finds the path of the file
      const fileExt = path.extname(filePath); // ensures fileExt correspond to filepath 'html'
      if(fileExt=='.html'){
          fs.exists(filePath, (exists)=>{
              if(!exists){
                  res.statusCode=404;
                  res.setHeader('Content-type','text/html');
                  res.end('<html><body></body><h1>Error 404: '+fileUrl+'not found</h1></html>');
                  return;
              }// checks whether file exists
              res.statusCode = 200;
              res.setHeader('Content-type','text/html');
              fs.createReadStream(filePath).pipe(res);
          }); // check to see if filepath exists
      }
      else 
      {
                  res.statusCode=404;
                  res.setHeader('Content-type','text/html');
                  res.end('<html><body></body><h1>Error 404: '+fileUrl+'not HTML file</h1></html>');
                  return;

      }
  }
  else{
                  res.statusCode=404;
                  res.setHeader('Content-type','text/html');
                  res.end('<html><body></body><h1>Error 404: '+req.method+'not supported</h1></html>');
                  return;

  }
}) ;

server.listen(port, hostname,()=>{
  console.log(`server running at http://${hostname}:${port}`);
});